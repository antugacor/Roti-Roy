document.addEventListener("DOMContentLoaded", function() {
    const orderButton = document.getElementById("orderButton");
    orderButton.addEventListener("click", function() {
        alert("Pesanan Anda telah diterima! Terima kasih telah memilih Roti Roi.");
    });
});
